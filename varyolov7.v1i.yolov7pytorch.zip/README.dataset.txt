# varyolov7 > 2025-06-10 12:11am
https://universe.roboflow.com/baltazar-bqikx/varyolov7

Provided by a Roboflow user
License: CC BY 4.0

